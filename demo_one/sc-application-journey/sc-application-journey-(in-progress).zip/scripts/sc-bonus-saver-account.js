/* global Utils, _satellite, digitalData */
class Features {
  /**
   * Init function to be called on page load
   */
  init() {
    const parentThis = this;
    const labels = document.querySelectorAll(
      ".sc-li-campaign__policy-type-filter-step-item"
    );
    if (labels.length) {
      labels.forEach((elem) => {
        elem.addEventListener("click", (e) => {
          parentThis.labelEvtCallback(e);
        });

        elem.addEventListener("keyup", function (e) {
          if (e.keyCode == 13 || e.keyCode == 32) {
            e.target.click();
          }
        });
      });
    }
  }
  /**
   * On click event callback function
   * @param {object} e
   * @example
   *
   * this.labelEvtCallback(e);
   *
   */
  labelEvtCallback(e) {
    const targetelem = document.querySelectorAll(
      ".sc-li-campaign__policy-type-filter-step-item"
    );
    targetelem.forEach((el) => {
      el.classList.remove(
        "sc-li-campaign__policy-type-filter-step-item--active"
      );
    });
    e.target.classList.add(
      "sc-li-campaign__policy-type-filter-step-item--active"
    );
    let labelFor = e.target;
  }
}

const instance = new Features();
instance.init();
// export default instance;
