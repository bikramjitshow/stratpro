/* global Utils, _satellite, digitalData */
class Privileges {
  /**
   * Init function to be called on page load
   */
  init() {
    const parentThis = this;
    const labels = document.querySelectorAll(".sc-privileges__step-item");
    if (labels.length) {
      labels.forEach((elem) => {
        elem.addEventListener("click", (e) => {
          parentThis.labelEvtCallback(e);
        });

        elem.addEventListener("keyup", function (e) {
          if (e.keyCode == 13 || e.keyCode == 32) {
            e.target.click();
          }
        });
      });
    }
  }
  /**
   * On click event callback function
   * @param {object} e
   * @example
   *
   * this.labelEvtCallback(e);
   *
   */
  labelEvtCallback(e) {
    const labels = document.querySelectorAll(".sc-privileges__step-item");
    labels.forEach((el) => {
      el.classList.remove("sc-privileges__step-item--active");
    });
    let labelFor = e.target.getAttribute("for");
    let selectedLabels = document.querySelectorAll(`label[for=${labelFor}]`);
    selectedLabels.forEach((el) => {
      el.classList.add("sc-privileges__step-item--active");
    });

    if (Utils.getCurrentCountry() === "hk") {
      let closest = e.target.closest(".sc-privileges__content-wrapper");
      // let selector = closest.querySelector('.sc-tab__item-title');
      let anchorText = e.target.innerText
        ? e.target.innerText.trim().toLowerCase()
        : e.target.textContent.trim().toLowerCase();

      digitalData.ctaName = anchorText;
      digitalData.ctaPosition = Utils.calcElementLocation(closest);
      _satellite.track("callToAction");
    }
  }
}

const instance = new Privileges();
window.addEventListener("load", function () {
  instance.init();
});
export default instance;
